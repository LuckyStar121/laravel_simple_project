<?php $__env->startSection('content'); ?>
    <div id="content" class="flex ">
        <!-- ############ Main START-->

        <div class="d-flex flex" id="content-body">
            <div class="d-flex flex-column flex" data-plugin="user">
                <div class="scroll-y mx-3 mb-3 card">
                    <div class="p-4 d-sm-flex no-shrink b-b">
                        <div>
                            <a href="#" class="avatar w-96">
                                <img src="<?php echo e(asset('assets/img/a5.jpg')); ?>" alt=".">
                            </a>
                        </div>
                        <div class="px-sm-4 my-3 my-sm-0 flex">
                            <h2 class="text-lg"><?php echo e($user->name); ?></h2>
                            
                            <div class="my-3">
                                <a href="#">
                                    <span class="text-muted">Email: </span><strong><?php echo e($user->email); ?></strong>
                                </a>
                                <a href="#" class="mx-2">
                                    <span class="text-muted">Phone: </span><strong><?php echo e($user->phone); ?></strong>
                                </a>
                                <a href="#" class="mx-2">
                                    <span class="text-muted">Count: </span><strong><?php echo e($count); ?></strong>
                                </a>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div>
                            <a href="#" class="btn btn-icon btn-rounded">
                                <i data-feather="mail"></i>
                            </a>
                            <a href="#" class="btn btn-icon btn-rounded">
                                <i data-feather="more-vertical"></i>
                            </a>
                        </div>
                    </div>
                    <div class="row no-gutters">
                        <div class="col-md-4">
                            <div class="p-4">
                                <h6>Members</h6>
                                <div class="list list-row">
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list-item no-border">
                                        <div>
                                            <a href="#">
                                                <span class="w-40 avatar gd-info">
								                    <span class="avatar-status off b-white avatar-right"></span>
                                                </span>
                                            </a>
                                        </div>
                                        <div class="flex">
                                            <a href="#" class="item-author text-color "><h4><?php echo e($member->member_name); ?></h4></a>
                                            <a href="#" class="item-company text-muted h-1x">
                                                <?php echo e("Address: ".$member->member_address); ?>

                                            </a>
                                            <a href="#" class="item-company text-muted h-1x">
                                                <?php echo e("Phone: ".$member->member_phone); ?>

                                            </a>
                                            <a href="#" class="item-company text-muted h-1x">
                                                <?php echo e("Email: ".$member->member_email); ?>

                                            </a>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 b-r">
                            <div class="p-4">
                                <h6>Notification Logs</h6>
                                <div class="timeline timeline-theme animates animates-fadeInUp bg-black">
                                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tl-item">
                                        <div class="tl-dot ">
                                        </div>
                                        <div class="tl-content">
                                            <div class=""><?php echo e($message); ?></div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="text-center">
                                    <a href="#" class="btn btn-sm btn-primary btn-rounded">Load more</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- Main END -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dev_myolarm\resources\views/pages/userdetail.blade.php ENDPATH**/ ?>